This project exists so the cmake build steps in uberenv-serac can execute
a cmake build of *something* and not fail early before the serac host
config has been created as part of the spack build/install process.
