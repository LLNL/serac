#include <iostream>
int
main(int argc, char *argv[])
{
    std::cout << "Hello from uberenv-serac." << std::endl;
    return 0;
}
